import java.util.Scanner;// we have to import the scanner clasd to get the user input

public class Leapyear {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);//we want to get the user input by using scanner class
        int year;
        System.out.println("Enter the year:::");// user to select a year
        year=scanner.nextInt();
        if((year/4==0)||(year%100!=0)||(year%400!=0)){//condition if a year is divisible by 4 without remainder


            System.out.println("the year is a leap year go and rest");// this conditipn will be met
        }
        else {
            System.out.println("you have to keep trying cus it is not a leap year .ok?");/*if the if condition did not met,
          the else condition will met*/
        }



    }
}
